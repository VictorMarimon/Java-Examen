package CONTROLADOR.CLIENTES;

import MODELO.DAO.CLIENTES.ClientesDAO;

public class ControladorCliente extends ClientesDAO {
    public String obtenerNombreCliente(Object object){
        return nombreCliente(object);
    }

    public String estado(Object object){
        return estadoCliente(object);
    }
}
