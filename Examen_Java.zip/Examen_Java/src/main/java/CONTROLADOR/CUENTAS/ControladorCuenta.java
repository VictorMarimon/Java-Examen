package CONTROLADOR.CUENTAS;

import MODELO.DAO.CHEQUES.Cheques;
import MODELO.DAO.CLIENTES.Clientes;
import MODELO.DAO.CUENTAS.Cuentas;
import MODELO.DAO.CUENTAS.CuentasDAO;

public class ControladorCuenta extends CuentasDAO {
    public int saldo(Clientes clientes){
        return saldoCliente(clientes);
    }

    public boolean nuevoSaldo(Cuentas cuentas, Clientes clientes){
        return modificarSaldo(cuentas, clientes);
    }

    public String estado(Object object){
        return estadoCuenta(object);
    }
}
