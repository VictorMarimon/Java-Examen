package CONTROLADOR.CHEQUES;

import MODELO.DAO.CHEQUES.Cheques;
import MODELO.DAO.CHEQUES.ChequesDAO;
import MODELO.DAO.CLIENTES.Clientes;

public class ControladorCheques extends ChequesDAO {
    public boolean nuevoCheque(Object object, Clientes clientes){
        return ingresarCheque(object, clientes);
    }

    public String idCheque (){
        return ultimoIdCheque();
    }

    public String fechaCheque(){
        return ultimoFechaEmisionCheque();
    }

    public boolean rechazo(Cheques cheques){
        return modificarRechazo(cheques);
    }

    public Object [][] reportesEmitidos(){
        return obtenerReportesEmitidos();
    }

    public Object [][] reportesPendientes(){
        return obtenerReportesPendientes();
    }

    public String fecha(){
        return obtenerFecha();
    }

    public String hora(){
        return obtenerHora();
    }
}
