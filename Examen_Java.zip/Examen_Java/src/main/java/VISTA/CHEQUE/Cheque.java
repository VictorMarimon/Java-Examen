package VISTA.CHEQUE;

import CONTROLADOR.CHEQUES.ControladorCheques;
import CONTROLADOR.CLIENTES.ControladorCliente;
import CONTROLADOR.CUENTAS.ControladorCuenta;
import MODELO.DAO.CHEQUES.Cheques;
import MODELO.DAO.CLIENTES.Clientes;
import MODELO.DAO.CUENTAS.Cuentas;
import VISTA.Menu;

import java.util.Scanner;

public class Cheque {
    Scanner entrada = new Scanner(System.in);

    ControladorCheques cCheques = new ControladorCheques();
    ControladorCliente cCliente = new ControladorCliente();
    ControladorCuenta cCuentas = new ControladorCuenta();

    public Cheque() {
    }

    public void menuCheque(){

        int option = 0;

        System.out.println("""
                1- Emitir Cheques
                2- Reporte Cheques Pendientes
                3- Menu principal
                """);
        option = entrada.nextInt();

        switch (option){
            case 1 :{
                emitirCheque();
            }
            case 2 :{
                chequesPendientesReporte();
            }
            case 3 :{
                Menu menu = new Menu();
                menu.menuPrincipal();
            }
        }

    }

    public void emitirCheque(){

        //    -   Antes de cualquier operación, verificar que el cliente esté activo y tenga cuentas válidas.

        Clientes clientes = new Clientes();
        Cheques cheques = new Cheques();
        Cuentas cuentas = new Cuentas();

        float monto_numeros = 0;

        //nombre emisor cheque
        cCliente.obtenerNombreCliente(clientes);

        System.out.print("Identificación: ");

        try {
            String identificacion = entrada.next();
            clientes.setIdentificacion(identificacion);
        }catch (Exception e){
            System.out.println("Por favor ingrese la identificación en números");
            emitirCheque();
        }

        System.out.print("Nombre beneficiario: ");
        String nombre_beneficiario = entrada.next();

        cheques.setBeneficiario(nombre_beneficiario);

        System.out.print("Monto (Números): ");

        try {
            monto_numeros = entrada.nextFloat();
            cheques.setMonto(monto_numeros);
        }catch (Exception e){
            System.out.println("Por favor ingrese el monto en números");
            emitirCheque();
        }

        System.out.print("Monto (Letras): ");
        String monto_letras = entrada.next();

        cheques.setMonto_letras(monto_letras);

        System.out.print("Firma digital: ");
        String firma_digital = entrada.next();

        cheques.setFirma_digital(firma_digital);

        System.out.print("Nivel de prioridad: ");
        String nivel_prioridad = entrada.next();

        if (nivel_prioridad.equals("Alta") || nivel_prioridad.equals("Media") || nivel_prioridad.equals("Baja") ){
            cheques.setPrioridad(nivel_prioridad);

            cheques.setEstado("Pendiente");

            boolean banderaRechazoCliente = false;
            boolean banderaRechazoCuenta = false;
            boolean banderaRechazoSaldo = false;

            if (cCliente.estado(clientes).equals("Inactivo") ){
                System.out.println("El cliente está inactivo.");
                cheques.setEstado("Rechazado");
                cheques.setRazon_rechazo("Cliente inactivo");
                banderaRechazoCliente = true;
            } else if (cCuentas.estado(clientes).equals("Cerrada")){
                System.out.println("La cuenta esta cerrada.");
                cheques.setEstado("Rechazado");
                cheques.setRazon_rechazo("Cuenta inactiva");
                banderaRechazoCuenta = true;
            }else if (monto_numeros > cCuentas.saldoCliente(clientes)){
                System.out.println("Excede el limite de saldo disponible");
                cheques.setEstado("Rechazado");
                cheques.setRazon_rechazo("Saldo insuficiente");
                banderaRechazoSaldo = true;
            }
            else {
                cuentas.setSaldo(monto_numeros - cCuentas.saldoCliente(clientes));
                cCuentas.nuevoSaldo(cuentas, clientes);
            }

            cheques.setNumero_cheque(cCheques.idCheque());

            cCheques.ingresarCheque(cheques, clientes);

            if (banderaRechazoCliente || banderaRechazoCuenta || banderaRechazoSaldo){
                cCheques.rechazo(cheques);
            }

            chequeEmitido(cCheques.idCheque(), cCheques.fechaCheque(), nombre_beneficiario, monto_letras, (int) monto_numeros, firma_digital);

            menuCheque();
        }else {
            System.out.println("Por favor ingrese una prioridad correcta ('Alta', 'Media', 'Baja')");
            System.out.println();
            emitirCheque();
        }
    }

    public void chequesPendientesReporte(){

        Object [][] datos = cCheques.reportesPendientes();

        System.out.println("---------------------------------");
        System.out.println("Resultados del Procesamiento de Cheques Pendientes");
        System.out.println("Fecha de procesamiento: " + cCheques.fecha());
        System.out.println("---------------------------------");

        for (int i = 0; i < datos.length; i++) {
            System.out.println("Cheque ID: "+ datos[i][0]);
            System.out.println("Cliente: "+ datos[i][1]);
            System.out.println("Beneficiario: "+ datos[i][2]);
            System.out.println("Monto: $"+ datos[i][3]);
            System.out.println("Estado: "+ datos[i][4]);
            System.out.println("Razón: "+ datos[i][5]);
            System.out.println();
        }


        menuCheque();
    }

    public void chequeEmitido(String id, String fecha, String beneficiario, String monto_cadena, int monto_numeros, String firma_digital){
        System.out.println("---------------------------------");
        System.out.println("BANCO UNIÓN S.A.");
        System.out.println("Cheque No: " + id);
        System.out.println("Fecha: " + fecha);
        System.out.println("");
        System.out.println("PAGUESE A: " + beneficiario);
        System.out.println("LA SUMA DE: " + monto_cadena);
        System.out.println("");
        System.out.println("Valor: $" + monto_numeros);
        System.out.println("");
        System.out.println("FIRMA DIGITAL: " + firma_digital);
        System.out.println("---------------------------------");
    }
}
