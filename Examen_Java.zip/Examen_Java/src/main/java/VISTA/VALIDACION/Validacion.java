package VISTA.VALIDACION;

public class Validacion {

    public Validacion() {
    }
}
