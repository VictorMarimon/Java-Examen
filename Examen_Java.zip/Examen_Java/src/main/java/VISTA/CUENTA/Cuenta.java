package VISTA.CUENTA;

public class Cuenta {
    public Cuenta() {
    }
}
