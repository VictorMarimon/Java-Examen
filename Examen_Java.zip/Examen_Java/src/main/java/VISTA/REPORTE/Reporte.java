package VISTA.REPORTE;

import CONTROLADOR.CHEQUES.ControladorCheques;

public class Reporte {
    ControladorCheques cCheques = new ControladorCheques();
    public Reporte() {
    }

    public void reportes(){

        Object [][] datos = cCheques.reportesEmitidos();

        System.out.println("---------------------------------");
        System.out.println("Resultados del Procesamiento de Cheques Emitidos");
        System.out.println("Fecha de procesamiento: " + cCheques.fecha());
        System.out.println("---------------------------------");

        for (int i = 0; i < datos.length; i++) {
            System.out.println("Cliente: "+ datos[i][0]);
            System.out.println("Beneficiario: "+ datos[i][1]);
            System.out.println("Monto: $"+ datos[i][2]);
            System.out.println("Prioridad: "+ datos[i][3]);
            System.out.println();
        }
    }
}
