package VISTA;

import VISTA.CHEQUE.Cheque;
import VISTA.REPORTE.Reporte;

import java.util.Scanner;

public class Menu {
    public Menu(){}
    public int menuPrincipal(){
        Scanner entrada = new Scanner(System.in);

        int option = 0;

        System.out.println("""
                
                ---------------------------------
                                
                          MENU PRINCIPAL
                                
                ---------------------------------
                
                1- Cheques
                2- Reportes
                3- Cuentas
                4- Clientes
                5- Transacciones
                6- Salir
                """);

        option = entrada.nextInt();

        switch (option){
            case 1:
            {
                Cheque ch = new Cheque();
                ch.menuCheque();
            }
            case 2:{
                Reporte r = new Reporte();
                r.reportes();
            }
            case 3:{

            }
            case 4:{

            }
        }


        return option;
    }

    public static void main(String[] args) {
        Menu m = new Menu();

        m.menuPrincipal();
    }
}
