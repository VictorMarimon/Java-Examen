package MODELO.DAO.CUENTAS;

public class Cuentas {
    private String tipo;
    private float saldo;
    private float limite_saldo;
    private String fecha_apertura;
    private String estado;

    public Cuentas(){}

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public float getSaldo() {
        return saldo;
    }

    public void setSaldo(float saldo) {
        this.saldo = saldo;
    }

    public float getLimite_saldo() {
        return limite_saldo;
    }

    public void setLimite_saldo(float limite_saldo) {
        this.limite_saldo = limite_saldo;
    }

    public String getFecha_apertura() {
        return fecha_apertura;
    }

    public void setFecha_apertura(String fecha_apertura) {
        this.fecha_apertura = fecha_apertura;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
}
