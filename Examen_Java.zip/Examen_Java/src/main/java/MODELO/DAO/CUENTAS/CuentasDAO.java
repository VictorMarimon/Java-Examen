package MODELO.DAO.CUENTAS;

import MODELO.CONEXION.Conexion;
import MODELO.DAO.CHEQUES.Cheques;
import MODELO.DAO.CLIENTES.Clientes;
import MODELO.DAO.CLIENTES.ClientesDAO;
import MODELO.DAO.IDAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;

public class CuentasDAO implements IDAO {
    private Conexion conexionInst = Conexion.getInstance();
    @Override
    public List<String> listar() {
        return null;
    }

    @Override
    public boolean buscar(Object object) {
        return false;
    }

    @Override
    public boolean agregar(Object object) {
        return false;
    }

    @Override
    public boolean modificar(Object object) {
        return false;
    }

    public int cuentaIdCliente(Object object){
            Clientes cliente = (Clientes) object;

            ClientesDAO clienteDAO = new ClientesDAO();

            PreparedStatement ps;
            ResultSet rs;

            Connection con = conexionInst.getConexion();

            var sql = "SELECT id FROM cuentas WHERE id_cliente = ?;";

            int ID;

            try{
                ps = con.prepareStatement(sql);
                ps.setString(1, clienteDAO.idCliente(cliente));
                rs = ps.executeQuery();

                if (rs.next()){
                    ID = rs.getInt("id");
                    return ID;
                }

            } catch (Exception e) {
                System.out.println("Error al buscar id estado empresa por estado " + e.getMessage());
            }finally {
                try{
                    con.close();
                } catch (Exception e) {
                    System.out.println("Error al cerrar conexión " + e.getMessage());
                }
            }
            ID = -1;

            return ID;
    }

    public int saldoCliente(Clientes cliente){

        ClientesDAO cDAO = new ClientesDAO();

        PreparedStatement ps;
        ResultSet rs;

        Connection con = conexionInst.getConexion();

        var sql = "select saldo from cuentas where id_cliente = ?;";

        int saldoTotal;

        try{
            ps = con.prepareStatement(sql);
            ps.setString(1, cDAO.idCliente(cliente));
            rs = ps.executeQuery();

            if (rs.next()){
                saldoTotal = rs.getInt("saldo");
                return saldoTotal;
            }

        } catch (Exception e) {
            System.out.println("Error al buscar el saldo del cliente " + e.getMessage());
        }finally {
            try{
                con.close();
            } catch (Exception e) {
                System.out.println("Error al cerrar conexión " + e.getMessage());
            }
        }
        saldoTotal = 0;

        return saldoTotal;
    }

    public boolean modificarSaldo(Cuentas cuentas, Clientes clientes) {

        ClientesDAO cDAO = new ClientesDAO();

        PreparedStatement ps;

        Connection con = conexionInst.getConexion();

        var sql = "UPDATE cuentas\n" +
                  "SET saldo = ?\n" +
                  "WHERE id_cliente = ?;";

        try{
            ps = con.prepareStatement(sql);

            ps.setFloat(1, cuentas.getSaldo());
            ps.setString(2, cDAO.idCliente(clientes));
            ps.execute();
            return true;
        } catch (Exception e) {
            System.out.println("Error al modificar persona " + e.getMessage());
        }finally {
            try{
                con.close();
            } catch (Exception e) {
                System.out.println("Error al cerrar conexión " + e.getMessage());
            }
        }

        return false;
    }

    public String estadoCuenta(Object object){
        Clientes cliente = (Clientes) object;

        ClientesDAO cDAO = new ClientesDAO();

        PreparedStatement ps;
        ResultSet rs;

        Connection con = conexionInst.getConexion();

        var sql = "SELECT estado FROM cuentas WHERE id_cliente = ?;";

        String estado;

        try{
            ps = con.prepareStatement(sql);
            ps.setString(1, cDAO.idCliente(cliente));
            rs = ps.executeQuery();

            if (rs.next()){
                estado = rs.getString("estado");
                return estado;
            }

        } catch (Exception e) {
            System.out.println("Error al buscar el estado de la cuenta " + e.getMessage());
        }finally {
            try{
                con.close();
            } catch (Exception e) {
                System.out.println("Error al cerrar conexión " + e.getMessage());
            }
        }
        estado = "";

        return estado;
    }

    public static void main(String[] args) {
        Clientes c = new Clientes();
        CuentasDAO cDAO = new CuentasDAO();

        c.setIdentificacion("777555888");

        System.out.println(cDAO.saldoCliente(c));
    }

}
