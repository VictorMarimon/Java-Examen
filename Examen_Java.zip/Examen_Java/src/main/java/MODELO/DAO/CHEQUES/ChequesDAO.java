package MODELO.DAO.CHEQUES;

import MODELO.CONEXION.Conexion;
import MODELO.DAO.CLIENTES.Clientes;
import MODELO.DAO.CLIENTES.ClientesDAO;
import MODELO.DAO.CUENTAS.Cuentas;
import MODELO.DAO.CUENTAS.CuentasDAO;
import MODELO.DAO.IDAO;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class ChequesDAO implements IDAO {

    private Conexion conexionInst = Conexion.getInstance();
    @Override
    public List<String> listar() {
            List<String> estados = new ArrayList<>();

            PreparedStatement ps;
            ResultSet rs;

            Connection con = conexionInst.getConexion();

            var sql = "SELECT cheques.numero_cheque, clientes.nombre, cheques.beneficiario, cheques.monto, cheques.estado, cheques.razon_rechazo FROM cheques INNER JOIN cuentas ON cheques.id_cuenta = cuentas.id INNER JOIN clientes ON cuentas.id_cliente = clientes.id;\n";

            try {
                ps = con.prepareStatement(sql);
                rs = ps.executeQuery();

                while (rs.next()) {
                    estados.add(rs.getString("ESTADO_PER"));
                }

            } catch (Exception e) {
                System.out.println("Hubo un error al listar cheques: " + e.getMessage());
            } finally {
                try {
                    con.close();
                } catch (Exception e) {
                    System.out.println("Error al cerrar conexión: " + e.getMessage());
                }
            }
            return estados;

    }

    @Override
    public boolean buscar(Object object) {
        return false;
    }

    @Override
    public boolean agregar(Object object) {
        return false;
    }

    @Override
    public boolean modificar(Object object) {
        return false;
    }

    public boolean ingresarCheque(Object object, Clientes cliente){

        CuentasDAO cDAO = new CuentasDAO();

        Cheques cheque = (Cheques) object;

        PreparedStatement ps;

        Connection con = conexionInst.getConexion();

        var sql = "INSERT INTO cheques(id_cuenta, beneficiario, monto, monto_letras, prioridad, firma_digital, estado, fecha_emision)\n" +
                  "VALUES(?, ?, ?, ?, ?, ?, ?, NOW());";

        try{
            ps = con.prepareStatement(sql);

            ps.setInt(1, cDAO.cuentaIdCliente(cliente));
            ps.setString(2, cheque.getBeneficiario());
            ps.setFloat(3, cheque.getMonto());
            ps.setString(4, cheque.getMonto_letras());
            ps.setString(5, cheque.getPrioridad());
            ps.setString(6, cheque.getFirma_digital());
            ps.setString(7, cheque.getEstado());

            ps.execute();
            return true;

        } catch (Exception e) {
            System.out.println("Error al agregar persona " + e.getMessage());
        }finally {
            try{
                con.close();
            } catch (Exception e) {
                System.out.println("Error al cerrar conexión " + e.getMessage());
            }
        }
        return false;
    }

    public String ultimoIdCheque(){

        PreparedStatement ps;
        ResultSet rs;

        Connection con = conexionInst.getConexion();

        var sql = "select numero_cheque from cheques ORDER BY id DESC LIMIT 1;";

        String nombre;

        try{
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();

            if (rs.next()){
                nombre = rs.getString("numero_cheque");
                return nombre;
            }

        } catch (Exception e) {
            System.out.println("Error al buscar el id del cheque " + e.getMessage());
        }finally {
            try{
                con.close();
            } catch (Exception e) {
                System.out.println("Error al cerrar conexión " + e.getMessage());
            }
        }
        nombre = "";

        return nombre;
    }

    public String ultimoFechaEmisionCheque(){

        PreparedStatement ps;
        ResultSet rs;

        Connection con = conexionInst.getConexion();

        var sql = "select fecha_emision from cheques ORDER BY id DESC LIMIT 1;";

        String nombre;

        try{
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();

            if (rs.next()){
                nombre = rs.getString("fecha_emision");
                return nombre;
            }

        } catch (Exception e) {
            System.out.println("Error al buscar la ultima fecha de emisión del cheque " + e.getMessage());
        }finally {
            try{
                con.close();
            } catch (Exception e) {
                System.out.println("Error al cerrar conexión " + e.getMessage());
            }
        }
        nombre = "";

        return nombre;
    }

    public boolean modificarRechazo(Cheques cheques) {

        PreparedStatement ps;

        Connection con = conexionInst.getConexion();

        var sql = "UPDATE cheques\n" +
                  "SET razon_rechazo = ?\n" +
                  "WHERE numero_cheque = ?;";

        try{
            ps = con.prepareStatement(sql);

            ps.setString(1, cheques.getRazon_rechazo());
            ps.setString(2, cheques.getNumero_cheque());
            ps.execute();
            return true;
        } catch (Exception e) {
            System.out.println("Error al modificar el rechazo del cheque " + e.getMessage());
        }finally {
            try{
                con.close();
            } catch (Exception e) {
                System.out.println("Error al cerrar conexión " + e.getMessage());
            }
        }

        return false;
    }

    public Object[][] obtenerReportesPendientes(){

        ArrayList<Object[]> listaDatos = new ArrayList<>();

        PreparedStatement ps;
        ResultSet rs;

        Connection con = conexionInst.getConexion();

        var sql = "SELECT cheques.id, clientes.nombre, cheques.beneficiario, cheques.monto, cheques.estado, cheques.razon_rechazo  FROM cheques\n" +
                  "INNER JOIN cuentas\n" +
                  "ON cheques.id_cuenta = cuentas.id\n" +
                  "INNER JOIN clientes\n" +
                  "ON cuentas.id = clientes.id WHERE cheques.estado = 'Rechazado' OR 'Procesado'";

        try{
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();

            while (rs.next()){
                listaDatos.add(new Object[]{
                        rs.getString("id"),
                        rs.getString("nombre"),
                        rs.getString("beneficiario"),
                        rs.getString("monto"),
                        rs.getString("estado"),
                        rs.getString("razon_rechazo")
                });
            }

        } catch (Exception e) {
            System.out.println("Error al listar cheques " + e.getMessage());
        }finally {
            try{
                con.close();
            } catch (Exception e) {
                System.out.println("Error al cerrar conexión " + e.getMessage());
            }
        }


        Object[][] data = new Object[listaDatos.size()][14];
        for (int i = 0; i < listaDatos.size(); i++) {
            data[i] = listaDatos.get(i);
        }

        String fecha = obtenerFecha();

        String hora = obtenerHora();

        String archivo = fecha + "-" + hora + "-procesamiento-cheques-pendientes.txt";


            try (BufferedWriter writer = new BufferedWriter(new FileWriter(archivo, false))) {

                for (int i = 0; i < data.length; i++) {
                    writer.write("Cheque ID: " + data[i][0]);
                    writer.newLine();
                    writer.write("Cliente: "+ data[i][1]);
                    writer.newLine();
                    writer.write("Beneficiario: "+ data[i][2]);
                    writer.newLine();
                    writer.write("Monto: $"+ data[i][3]);
                    writer.newLine();
                    writer.write("Estado: "+ data[i][4]);
                    writer.newLine();
                    writer.write("Razón: "+ data[i][5]);
                    writer.write("                   ");
                    writer.newLine();
                    writer.newLine();
                }
            } catch (Exception e) {
                System.out.println("Error al guardar los reportes" + e.getMessage());
            }
        return data;
    }

    public Object[][] obtenerReportesEmitidos(){

        ArrayList<Object[]> listaDatos = new ArrayList<>();

        PreparedStatement ps;
        ResultSet rs;

        Connection con = conexionInst.getConexion();

        var sql = "SELECT clientes.nombre, cheques.beneficiario, cheques.monto, cheques.prioridad  FROM cheques\n" +
                  "INNER JOIN cuentas\n" +
                  "ON cheques.id_cuenta = cuentas.id\n" +
                  "INNER JOIN clientes\n" +
                  "ON cuentas.id = clientes.id\n" +
                  "ORDER BY cheques.prioridad ASC";

        try{
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();

            while (rs.next()){
                listaDatos.add(new Object[]{
                        rs.getString("nombre"),
                        rs.getString("beneficiario"),
                        rs.getString("monto"),
                        rs.getString("prioridad")
                });
            }

        } catch (Exception e) {
            System.out.println("Error al listar cheques emitidos " + e.getMessage());
        }finally {
            try{
                con.close();
            } catch (Exception e) {
                System.out.println("Error al cerrar conexión " + e.getMessage());
            }
        }


        Object[][] data = new Object[listaDatos.size()][14];
        for (int i = 0; i < listaDatos.size(); i++) {
            data[i] = listaDatos.get(i);
        }

        String fecha = obtenerFecha();

        String hora = obtenerHora();

        String archivo = fecha + "-" + hora + "-procesamiento-cheques-emitidos.txt";


        try (BufferedWriter writer = new BufferedWriter(new FileWriter(archivo, false))) {

            for (int i = 0; i < data.length; i++) {
                writer.write("Cliente: " + data[i][0]);
                writer.newLine();
                writer.write("Beneficiario: "+ data[i][1]);
                writer.newLine();
                writer.write("Monto: "+ data[i][2]);
                writer.newLine();
                writer.write("Prioridad: "+ data[i][3]);
                writer.newLine();
                writer.newLine();
            }
        } catch (Exception e) {
            System.out.println("Error al guardar los reportes emitidos" + e.getMessage());
        }
        return data;
    }

    public String obtenerFecha(){

        PreparedStatement ps;
        ResultSet rs;

        Connection con = conexionInst.getConexion();

        var sql = "SELECT CURDATE();";

        String fecha;

        try{
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();

            if (rs.next()){
                fecha = rs.getString("CURDATE()");
                return fecha;
            }

        } catch (Exception e) {
            System.out.println("Error al buscar la fecha actual " + e.getMessage());
        }finally {
            try{
                con.close();
            } catch (Exception e) {
                System.out.println("Error al cerrar conexión " + e.getMessage());
            }
        }
        fecha = "";

        return fecha;
    }

    public String obtenerHora(){

        PreparedStatement ps;
        ResultSet rs;

        Connection con = conexionInst.getConexion();

        var sql = "SELECT TIME(SYSDATE());";

        String hora;

        try{
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();

            if (rs.next()){
                hora = rs.getString("TIME(SYSDATE())");
                return hora;
            }

        } catch (Exception e) {
            System.out.println("Error al buscar la hora actual " + e.getMessage());
        }finally {
            try{
                con.close();
            } catch (Exception e) {
                System.out.println("Error al cerrar conexión " + e.getMessage());
            }
        }
        hora = "";

        return hora;
    }

    public static void main(String[] args) {
        ChequesDAO chequesDAO = new ChequesDAO();
        Cheques cheques = new Cheques();
        Clientes clientes = new Clientes();

        cheques.setBeneficiario("cristiano ronaldo");
        cheques.setMonto(20000);
        cheques.setMonto_letras("veinte mil");
        cheques.setPrioridad("Alta");
        cheques.setFirma_digital("aeiou");

        clientes.setIdentificacion("111999000");

        cheques.setNumero_cheque("CH0001073");
        cheques.setRazon_rechazo("Saldo insuficiente");


        System.out.println(chequesDAO.modificarRechazo(cheques));
    }
}
