package MODELO.DAO.CLIENTES;

import MODELO.CONEXION.Conexion;
import MODELO.DAO.IDAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;

public class ClientesDAO implements IDAO {
    private Conexion conexionInst = Conexion.getInstance();
    @Override
    public List<String> listar() {
        return null;
    }

    @Override
    public boolean buscar(Object object) {
        return false;
    }

    @Override
    public boolean agregar(Object object) {
        return false;
    }

    @Override
    public boolean modificar(Object object) {
        return false;
    }

    public String idCliente(Object object){
        Clientes cliente = (Clientes) object;

        PreparedStatement ps;
        ResultSet rs;

        Connection con = conexionInst.getConexion();

        var sql = "SELECT id FROM clientes WHERE identificacion = ?;";

        String ID;

        try{
            ps = con.prepareStatement(sql);
            ps.setString(1, cliente.getIdentificacion());
            rs = ps.executeQuery();

            if (rs.next()){
                ID = rs.getString("id");
                return ID;
            }

        } catch (Exception e) {
            System.out.println("Error al buscar id del cliente " + e.getMessage());
        }finally {
            try{
                con.close();
            } catch (Exception e) {
                System.out.println("Error al cerrar conexión " + e.getMessage());
            }
        }
        ID = "";

        return ID;
    }

    public String nombreCliente(Object object){
        Clientes cliente = (Clientes) object;

        PreparedStatement ps;
        ResultSet rs;

        Connection con = conexionInst.getConexion();

        var sql = "SELECT nombre FROM clientes WHERE identificacion = ?;";

        String nombre;

        try{
            ps = con.prepareStatement(sql);
            ps.setString(1, cliente.getIdentificacion());
            rs = ps.executeQuery();

            if (rs.next()){
                nombre = rs.getString("nombre");
                return nombre;
            }

        } catch (Exception e) {
            System.out.println("Error al buscar el nombre del cliente " + e.getMessage());
        }finally {
            try{
                con.close();
            } catch (Exception e) {
                System.out.println("Error al cerrar conexión " + e.getMessage());
            }
        }
        nombre = "";

        return nombre;
    }

    public String estadoCliente(Object object){
        Clientes cliente = (Clientes) object;

        PreparedStatement ps;
        ResultSet rs;

        Connection con = conexionInst.getConexion();

        var sql = "SELECT estado FROM clientes WHERE identificacion = ?;";

        String estado;

        try{
            ps = con.prepareStatement(sql);
            ps.setString(1, cliente.getIdentificacion());
            rs = ps.executeQuery();

            if (rs.next()){
                estado = rs.getString("estado");
                return estado;
            }

        } catch (Exception e) {
            System.out.println("Error al buscar el estado del cliente " + e.getMessage());
        }finally {
            try{
                con.close();
            } catch (Exception e) {
                System.out.println("Error al cerrar conexión " + e.getMessage());
            }
        }
        estado = "";

        return estado;
    }

    public static void main(String[] args) {
        Clientes c = new Clientes();
        ClientesDAO cDAO = new ClientesDAO();

        c.setIdentificacion("123456789");

        System.out.println(cDAO.idCliente(c));

    }
}
