package MODELO.DAO.TRANSACCIONES;

import MODELO.CONEXION.Conexion;
import MODELO.DAO.IDAO;

import java.util.List;

public class TransaccionesDAO implements IDAO {
    private Conexion conexionInst = Conexion.getInstance();
    @Override
    public List<String> listar() {
        return null;
    }

    @Override
    public boolean buscar(Object object) {
        return false;
    }

    @Override
    public boolean agregar(Object object) {
        return false;
    }

    @Override
    public boolean modificar(Object object) {
        return false;
    }
}
