package MODELO.DAO.TRANSACCIONES;

public class Transacciones {
    private String tipo;
    private float monto;
    private String fecha;
    private String referencia;
    private float saldo_anterior;
    private float saldo_nuevo;
    private String estado;

    public Transacciones(){}

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public float getMonto() {
        return monto;
    }

    public void setMonto(float monto) {
        this.monto = monto;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getReferencia() {
        return referencia;
    }

    public void setReferencia(String referencia) {
        this.referencia = referencia;
    }

    public float getSaldo_anterior() {
        return saldo_anterior;
    }

    public void setSaldo_anterior(float saldo_anterior) {
        this.saldo_anterior = saldo_anterior;
    }

    public float getSaldo_nuevo() {
        return saldo_nuevo;
    }

    public void setSaldo_nuevo(float saldo_nuevo) {
        this.saldo_nuevo = saldo_nuevo;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
}
